# SDUT-Competition-Registration-System
sdut竞赛报名系统
